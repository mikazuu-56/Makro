package com.example.macrolayout

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.view.accessibility.AccessibilityEvent

class MacroAccessibilityService : AccessibilityService() {
    companion object { var instance: MacroAccessibilityService? = null }

    override fun onServiceConnected() {
        instance = this
        android.widget.Toast.makeText(this, "MacroLayout tersambung", android.widget.Toast.LENGTH_SHORT).show()
    }
    override fun onUnbind(intent: android.content.Intent?): Boolean { instance = null; return super.onUnbind(intent) }
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    fun tapSequence(pts: List<Pair<Float, Float>>, gapMs: Long) {
        val dur = Math.max(10L, Math.min(40L, gapMs - 5))
        val b = GestureDescription.Builder()
        pts.take(GestureDescription.getMaxStrokeCount()).forEachIndexed { i, p ->
            val path = Path().apply { moveTo(p.first, p.second) }
            b.addStroke(GestureDescription.StrokeDescription(path, i * gapMs, dur))
        }
        dispatchGesture(b.build(), null, null)
    }

    fun tap(x: Float, y: Float, durationMs: Long = 50) {
        val path = Path().apply { moveTo(x, y) }
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, durationMs)).build()
        dispatchGesture(g, null, null)
    }
}

package com.example.macrolayout

import android.app.Service
import android.content.Intent
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class OverlayService : Service() {
    private class Pt(val v: TextView, val p: WindowManager.LayoutParams)
    private class Macro(val btn: LinearLayout, val circle: TextView, val label: TextView, val bp: WindowManager.LayoutParams, var delay: Long, val pts: MutableList<Pt> = mutableListOf())

    private lateinit var wm: WindowManager
    private lateinit var bar: LinearLayout
    private lateinit var bubble: TextView
    private lateinit var barP: WindowManager.LayoutParams
    private lateinit var bubbleP: WindowManager.LayoutParams
    private lateinit var delayChip: TextView
    private val macros = mutableListOf<Macro>()
    private var selected: Macro? = null
    private var edit = true
    private var busy = false
    private var land = false
    private val handler = Handler(Looper.getMainLooper())
    private val delays = longArrayOf(30, 50, 100, 150, 300, 500, 1000, 2000)

    private val BG = Color.parseColor("#E61A1D24")
    private val ACCENT = Color.parseColor("#4F8CFF")
    private val GREEN = Color.parseColor("#2ECC71")
    private val RED = Color.parseColor("#FF5252")
    private val GRAY = Color.parseColor("#33394A")
    private val palette = intArrayOf(
        Color.parseColor("#4F8CFF"), Color.parseColor("#FF8A4F"), Color.parseColor("#2ECC71"),
        Color.parseColor("#E056FD"), Color.parseColor("#F1C40F"), Color.parseColor("#1ABC9C")
    )

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private val ptSize get() = dp(40)
    private fun round(c: Int, r: Int) = GradientDrawable().apply { setColor(c); cornerRadius = dp(r).toFloat() }
    private fun oval(c: Int, stroke: Int = 0, strokeColor: Int = Color.WHITE) = GradientDrawable().apply {
        shape = GradientDrawable.OVAL; setColor(c); if (stroke > 0) setStroke(stroke, strokeColor)
    }
    private fun alpha(c: Int, a: Int) = Color.argb(a, Color.red(c), Color.green(c), Color.blue(c))

    override fun onBind(i: Intent?): IBinder? = null

    private fun lp(x: Int, y: Int) = WindowManager.LayoutParams(
        -2, -2, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
        PixelFormat.TRANSLUCENT
    ).apply { gravity = Gravity.TOP or Gravity.START; this.x = x; this.y = y }

    private fun dragListener(target: View, p: WindowManager.LayoutParams, onTap: (() -> Unit)? = null): View.OnTouchListener {
        var dx = 0f; var dy = 0f; var sx = 0; var sy = 0; var moved = false
        return View.OnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { dx = e.rawX; dy = e.rawY; sx = p.x; sy = p.y; moved = false }
                MotionEvent.ACTION_MOVE -> {
                    if (Math.abs(e.rawX - dx) > 10 || Math.abs(e.rawY - dy) > 10) moved = true
                    p.x = sx + (e.rawX - dx).toInt(); p.y = sy + (e.rawY - dy).toInt()
                    wm.updateViewLayout(target, p)
                }
                MotionEvent.ACTION_UP -> { if (!moved) onTap?.invoke() else save() }
            }
            true
        }
    }

    private fun btn(label: String, bg: Int, onClick: () -> Unit) = TextView(this).apply {
        text = label; setTextColor(Color.WHITE); textSize = 16f; gravity = Gravity.CENTER
        background = oval(bg)
        layoutParams = LinearLayout.LayoutParams(dp(44), dp(44)).apply { marginStart = dp(6) }
        setOnClickListener { onClick() }
    }

    private fun chip(onClick: () -> Unit) = TextView(this).apply {
        setTextColor(Color.WHITE); textSize = 13f; gravity = Gravity.CENTER; background = round(GRAY, 18)
        setPadding(dp(12), dp(9), dp(12), dp(9))
        layoutParams = LinearLayout.LayoutParams(-2, -2).apply { marginStart = dp(6) }
        setOnClickListener { onClick() }
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager

        bar = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL; background = round(BG, 30)
            setPadding(dp(8), dp(8), dp(10), dp(8))
        }
        val handle = TextView(this).apply {
            text = "⋮"; textSize = 24f; setTextColor(Color.GRAY); setPadding(dp(8), 0, dp(10), 0)
        }
        delayChip = chip {
            val m = selected
            if (m == null) toast("Ketuk tombol makro dulu") else {
                m.delay = delays[(delays.indexOf(m.delay).let { if (it < 0) 2 else it } + 1) % delays.size]
                updateUi(); save()
            }
        }
        bar.addView(handle)
        bar.addView(btn("+", ACCENT) {
            val m = addMacro(dp(300) + macros.size * dp(70), dp(120), 100)
            selected = m; refreshStyles(); updateUi(); save()
        })
        bar.addView(btn("◎", GREEN) {
            val m = selected
            if (m == null) toast("Ketuk tombol makro dulu") else { addPoint(m, dp(200), dp(200)); refreshStyles(); save() }
        })
        bar.addView(delayChip)
        bar.addView(btn("⌫", GRAY) { deleteSelected() })
        bar.addView(btn("✓", GREEN) { setEdit(false) })
        bar.addView(btn("✕", RED) { stopSelf() })

        bubble = TextView(this).apply {
            text = "⚙"; setTextColor(Color.WHITE); textSize = 18f; gravity = Gravity.CENTER
            minWidth = dp(40); minHeight = dp(40); background = oval(alpha(Color.BLACK, 90), dp(2), alpha(Color.WHITE, 110))
            visibility = View.GONE
        }
        barP = lp(dp(40), dp(24))
        bubbleP = lp(dp(40), dp(24))
        wm.addView(bar, barP)
        wm.addView(bubble, bubbleP)
        bar.getChildAt(0).setOnTouchListener(dragListener(bar, barP))
        bubble.setOnTouchListener(dragListener(bubble, bubbleP) { setEdit(true) })

        land = resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
        load()
        refreshStyles(); updateUi()
        setEdit(macros.isEmpty())
        if (macros.isEmpty()) toast("Ketuk + untuk membuat tombol")
    }

    private fun updateUi() { delayChip.text = selected?.let { "${it.delay} ms" } ?: "– ms" }

    private fun addMacro(x: Int, y: Int, delay: Long): Macro {
        val circle = TextView(this).apply {
            text = "⇄"; setTextColor(Color.WHITE); textSize = 22f; gravity = Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams(dp(52), dp(52))
        }
        val label = TextView(this).apply {
            setTextColor(alpha(Color.WHITE, 200)); textSize = 11f; gravity = Gravity.CENTER
            setPadding(0, dp(4), 0, 0)
        }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
            addView(circle); addView(label)
        }
        val p = lp(x, y)
        wm.addView(box, p)
        val m = Macro(box, circle, label, p, delay)
        val dl = dragListener(box, p) { selected = m; refreshStyles(); updateUi() }
        box.setOnTouchListener { v, e ->
            if (!edit) { if (e.action == MotionEvent.ACTION_DOWN) fire(m); true } else dl.onTouch(v, e)
        }
        macros.add(m)
        return m
    }

    private fun addPoint(m: Macro, x: Int, y: Int) {
        val tv = TextView(this).apply {
            setTextColor(Color.WHITE); textSize = 12f; gravity = Gravity.CENTER; minWidth = ptSize; minHeight = ptSize
            visibility = if (edit) View.VISIBLE else View.GONE
        }
        val p = lp(x, y)
        wm.addView(tv, p)
        tv.setOnTouchListener(dragListener(tv, p))
        m.pts.add(Pt(tv, p))
    }

    private fun deleteSelected() {
        val m = selected ?: run { toast("Ketuk tombol makro dulu"); return }
        m.pts.forEach { wm.removeView(it.v) }
        wm.removeView(m.btn)
        macros.remove(m); selected = null
        refreshStyles(); updateUi(); save()
    }

    private fun refreshStyles() {
        macros.forEachIndexed { i, m ->
            val sel = edit && m === selected
            m.label.text = if (i == 0) "Quick change" else "Quick change ${i + 1}"
            m.circle.background = if (sel) oval(alpha(Color.WHITE, 30), dp(3), ACCENT)
                                  else oval(alpha(Color.WHITE, 20), dp(2), alpha(Color.WHITE, 140))
            m.pts.forEachIndexed { j, pt ->
                pt.v.text = "${i + 1}.${j + 1}"
                pt.v.background = oval(alpha(ACCENT, if (sel) 150 else 90), dp(2), Color.WHITE)
            }
        }
    }

    private fun setEdit(e: Boolean) {
        edit = e
        if (e) { barP.x = bubbleP.x; barP.y = bubbleP.y; wm.updateViewLayout(bar, barP) }
        else { bubbleP.x = barP.x; bubbleP.y = barP.y; wm.updateViewLayout(bubble, bubbleP) }
        bar.visibility = if (e) View.VISIBLE else View.GONE
        bubble.visibility = if (e) View.GONE else View.VISIBLE
        macros.forEach { m -> m.pts.forEach { it.v.visibility = if (e) View.VISIBLE else View.GONE } }
        if (!e) { selected = null; save() }
        refreshStyles(); updateUi()
    }

    private fun setMacroTouchable(t: Boolean) = macros.forEach {
        it.bp.flags = if (t) it.bp.flags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.inv()
                      else it.bp.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        wm.updateViewLayout(it.btn, it.bp)
    }

    private fun fire(m: Macro) {
        val svc = MacroAccessibilityService.instance
        if (svc == null) { toast("Accessibility belum tersambung. Matikan lalu nyalakan lagi di pengaturan"); return }
        if (busy || m.pts.isEmpty()) return
        busy = true
        setMacroTouchable(false)
        var i = 0
        val r = object : Runnable {
            override fun run() {
                val pt = m.pts[i].p
                svc.tap(pt.x + ptSize / 2f, pt.y + ptSize / 2f, 30)
                i++
                if (i < m.pts.size) handler.postDelayed(this, m.delay)
                else handler.postDelayed({ busy = false; setMacroTouchable(true) }, 60)
            }
        }
        r.run()
    }

    private fun key() = if (land) "d_land" else "d_port"

    private fun clearAll() {
        macros.forEach { m -> m.pts.forEach { wm.removeView(it.v) }; wm.removeView(m.btn) }
        macros.clear(); selected = null
    }

    override fun onConfigurationChanged(c: Configuration) {
        super.onConfigurationChanged(c)
        val nl = c.orientation == Configuration.ORIENTATION_LANDSCAPE
        if (nl == land) return
        save(); clearAll(); land = nl
        barP.x = dp(40); barP.y = dp(24); bubbleP.x = dp(40); bubbleP.y = dp(24)
        wm.updateViewLayout(bar, barP); wm.updateViewLayout(bubble, bubbleP)
        load()
        setEdit(if (macros.isEmpty()) true else edit)
    }

    private fun save() {
        val sb = StringBuilder()
        macros.forEach { m ->
            sb.append("M,${m.bp.x},${m.bp.y},${m.delay}\n")
            m.pts.forEach { sb.append("P,${it.p.x},${it.p.y}\n") }
        }
        getSharedPreferences("layout", MODE_PRIVATE).edit().putString(key(), sb.toString()).apply()
    }

    private fun load() {
        val d = getSharedPreferences("layout", MODE_PRIVATE).getString(key(), "") ?: ""
        var cur: Macro? = null
        try {
            d.lines().forEach { l ->
                val a = l.split(",")
                when (a[0]) {
                    "M" -> cur = addMacro(a[1].toInt(), a[2].toInt(), a[3].toLong())
                    "P" -> cur?.let { addPoint(it, a[1].toInt(), a[2].toInt()) }
                }
            }
        } catch (e: Exception) { }
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        save()
        macros.forEach { m -> m.pts.forEach { wm.removeView(it.v) }; wm.removeView(m.btn) }
        wm.removeView(bar); wm.removeView(bubble)
        super.onDestroy()
    }
}

package com.example.macrolayout

import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private lateinit var panel: LinearLayout
    private val markers = mutableListOf<TextView>()
    private val handler = Handler(Looper.getMainLooper())
    private val delays = longArrayOf(50, 100, 150, 300, 500, 800, 1500, 3000)
    private var delayIdx = 3
    private var loopMode = false
    private lateinit var playBtn: Button
    private var running = false
    private var cur = 0
    private val size = 120

    override fun onBind(i: Intent?): IBinder? = null

    private fun lp(touchable: Boolean = true) = WindowManager.LayoutParams(
        WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
            (if (touchable) 0 else WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE),
        PixelFormat.TRANSLUCENT
    ).apply { gravity = Gravity.TOP or Gravity.START }

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.argb(160, 0, 0, 0))
        }
        val play = Button(this)
        playBtn = play
        val modeBtn = Button(this)
        val delayBtn = Button(this)
        fun refresh() { play.text = if (running) "■ Stop" else "▶ Play"; modeBtn.text = if (loopMode) "🔁 Loop" else "1x"; delayBtn.text = "⏱ ${delays[delayIdx]}ms" }
        play.setOnClickListener { if (running) stop() else start(); refresh() }
        delayBtn.setOnClickListener { delayIdx = (delayIdx + 1) % delays.size; refresh() }
        modeBtn.setOnClickListener { loopMode = !loopMode; refresh() }
        refresh()
        panel.addView(Button(this).apply { text = "+ Titik"; setOnClickListener { addMarker() } })
        panel.addView(play)
        panel.addView(delayBtn)
        panel.addView(modeBtn)
        panel.addView(Button(this).apply { text = "Hapus"; setOnClickListener { stop(); clearMarkers(); refresh() } })
        panel.addView(Button(this).apply { text = "✕ Tutup"; setOnClickListener { stopSelf() } })
        wm.addView(panel, lp().apply { x = 0; y = 200 })
    }

    private fun addMarker() {
        val tv = TextView(this).apply {
            text = "${markers.size + 1}"
            setTextColor(Color.WHITE); textSize = 20f; gravity = Gravity.CENTER
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.argb(150, 255, 60, 60)) }
        }
        val p = lp().apply { width = size; height = size; x = 400; y = 400 }
        var dx = 0f; var dy = 0f; var sx = 0; var sy = 0
        tv.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { dx = e.rawX; dy = e.rawY; sx = p.x; sy = p.y }
                MotionEvent.ACTION_MOVE -> {
                    p.x = sx + (e.rawX - dx).toInt(); p.y = sy + (e.rawY - dy).toInt()
                    wm.updateViewLayout(tv, p)
                }
            }
            true
        }
        wm.addView(tv, p)
        markers.add(tv)
    }

    private fun setMarkersTouchable(t: Boolean) = markers.forEach {
        val p = it.layoutParams as WindowManager.LayoutParams
        p.flags = if (t) p.flags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.inv()
                  else p.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        wm.updateViewLayout(it, p)
    }

    private val step = object : Runnable {
        override fun run() {
            if (!running || markers.isEmpty()) return
            val p = markers[cur].layoutParams as WindowManager.LayoutParams
            MacroAccessibilityService.instance?.tap(p.x + size / 2f, p.y + size / 2f)
            cur = (cur + 1) % markers.size
            if (cur == 0 && !loopMode) { stop(); playBtn.text = "▶ Play"; return }
            handler.postDelayed(this, delays[delayIdx])
        }
    }

    private fun start() {
        if (markers.isEmpty() || MacroAccessibilityService.instance == null) return
        running = true; cur = 0; setMarkersTouchable(false); handler.post(step)
    }

    private fun stop() {
        running = false; handler.removeCallbacks(step); setMarkersTouchable(true)
    }

    private fun clearMarkers() { markers.forEach { wm.removeView(it) }; markers.clear() }

    override fun onDestroy() {
        stop(); clearMarkers(); wm.removeView(panel); super.onDestroy()
    }
}

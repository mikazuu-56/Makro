package com.example.macrolayout

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {
    private lateinit var st1: TextView
    private lateinit var st2: TextView

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun round(c: Int, r: Int) = GradientDrawable().apply { setColor(c); cornerRadius = dp(r).toFloat() }

    private fun button(label: String, color: Int, onClick: () -> Unit) = TextView(this).apply {
        text = label; setTextColor(Color.WHITE); textSize = 15f; typeface = Typeface.DEFAULT_BOLD
        gravity = Gravity.CENTER; background = round(color, 14)
        setPadding(dp(16), dp(12), dp(16), dp(12))
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(12) }
        setOnClickListener { onClick() }
    }

    private fun card(no: String, title: String, desc: String, btnLabel: String, onClick: () -> Unit): TextView {
        val status = TextView(this).apply { textSize = 12f; typeface = Typeface.DEFAULT_BOLD }
        val head = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            addView(TextView(context).apply { text = "$no  $title"; setTextColor(Color.WHITE); textSize = 17f
                typeface = Typeface.DEFAULT_BOLD; layoutParams = LinearLayout.LayoutParams(0, -2, 1f) })
            addView(status)
        }
        val c = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; background = round(Color.parseColor("#1A1D24"), 20)
            setPadding(dp(18), dp(16), dp(18), dp(16))
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(14) }
            addView(head)
            addView(TextView(context).apply { text = desc; setTextColor(Color.parseColor("#9AA3B2")); textSize = 13f
                setPadding(0, dp(6), 0, 0) })
            addView(button(btnLabel, Color.parseColor("#2F3547"), onClick))
        }
        root.addView(c)
        return status
    }

    private lateinit var root: LinearLayout

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.statusBarColor = Color.parseColor("#0F1115")
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.parseColor("#0F1115"))
            setPadding(dp(20), dp(40), dp(20), dp(28))
        }
        root.addView(TextView(this).apply { text = "Macro Layout"; setTextColor(Color.WHITE); textSize = 30f; typeface = Typeface.DEFAULT_BOLD })
        root.addView(TextView(this).apply { text = "Titik ketuk melayang untuk game non-kompetitif"
            setTextColor(Color.parseColor("#9AA3B2")); textSize = 14f; setPadding(0, dp(4), 0, dp(8)) })
        st1 = card("1", "Izin overlay", "Agar panel bisa tampil di atas game.", "Buka pengaturan") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        st2 = card("2", "Accessibility Service", "Cari MacroLayout lalu aktifkan. Dipakai untuk mengirim ketukan.", "Buka pengaturan") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        root.addView(button("Tampilkan panel", Color.parseColor("#4F8CFF")) {
            if (!Settings.canDrawOverlays(this)) return@button
            startService(Intent(this, OverlayService::class.java)); moveTaskToBack(true)
        }.apply { textSize = 17f })
        setContentView(ScrollView(this).apply { setBackgroundColor(Color.parseColor("#0F1115")); addView(root) })
    }

    private val h = Handler(Looper.getMainLooper())
    private val poll = object : Runnable {
        override fun run() {
            fun set(t: TextView, ok: Boolean) {
                t.text = if (ok) "✓ Aktif" else "Belum aktif"
                t.setTextColor(Color.parseColor(if (ok) "#2ECC71" else "#FFB020"))
            }
            set(st1, Settings.canDrawOverlays(this@MainActivity))
            val on = MacroAccessibilityService.instance != null
            st2.text = if (on) "✓ Tersambung" else if (a11yOn()) "Aktif, belum tersambung" else "Belum aktif"
            st2.setTextColor(Color.parseColor(if (on) "#2ECC71" else "#FFB020"))
            h.postDelayed(this, 700)
        }
    }

    private fun a11yOn(): Boolean {
        val s = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        return s.contains(packageName) && s.contains("MacroAccessibilityService")
    }

    override fun onResume() { super.onResume(); h.post(poll) }
    override fun onPause() { super.onPause(); h.removeCallbacks(poll) }
}
